# quantum-error-correction

Portfolio repository for IBM Quantum Hackathon mentoring.
